// Self-Driving Car plugin — evaluated in renderer via new Function('api', code)(api)
(function (api) {
  'use strict';

  const CW = 700, CH = 530;

  // ── Palette ───────────────────────────────────────────────────────────────
  const COL = {
    trackFill:  '#1c1c1c', trackEdge:  '#3a3a3a',
    carAlive:   '#00e676', carDead:    '#662323',
    carBest:    '#ffd600', carInfer:   '#64b5f6',
    bg:         '#0d0d0d',
  };

  // ── Per-network config store ───────────────────────────────────────────────
  // Config lives here (renderer process) and is passed to the main process on init.
  const _pluginCfg = new Map();

  function defaultCfg() {
    return {
      // Sensor inputs
      rayCount:          9,
      raySpreadDeg:      160,
      rayMaxDist:        40,
      useSpeed:          true,
      useSteerMemory:    true,
      useDistToCenter:   false,
      useTrackCurvature: false,
      // Fitness
      progressWeight:    1.0,
      speedBonus:        0.01,
      survivalPenalty:   0.9,
      reversePenalty:   0.4,
      // Architecture
      hiddenStr:         '64, 32, 16',   // editable string → parsed to array
      activation:        'tanh',
      // Physics
      maxSpeed:          340,
      friction:          0.93,
      steerRate:         2.4,
    };
  }

  function getPluginCfg(netId) {
    if (!_pluginCfg.has(netId)) _pluginCfg.set(netId, defaultCfg());
    return _pluginCfg.get(netId);
  }

  function parseHidden(str) {
    return str.split(',').map(s => parseInt(s.trim(), 10)).filter(n => n > 0 && n <= 1024);
  }

  function computeInputDim(cfg) {
    return cfg.rayCount +
      (cfg.useSpeed          ? 1 : 0) +
      (cfg.useSteerMemory    ? 1 : 0) +
      (cfg.useDistToCenter   ? 1 : 0) +
      (cfg.useTrackCurvature ? 1 : 0);
  }

  function cfgToPayload(cfg) {
    const hidden = parseHidden(cfg.hiddenStr);
    return {
      sensorCfg: {
        rayCount:          cfg.rayCount,
        raySpreadDeg:      cfg.raySpreadDeg,
        rayMaxDist:        cfg.rayMaxDist,
        useSpeed:          cfg.useSpeed,
        useSteerMemory:    cfg.useSteerMemory,
        useDistToCenter:   cfg.useDistToCenter,
        useTrackCurvature: cfg.useTrackCurvature,
      },
      fitnessCfg: {
        progressWeight:  cfg.progressWeight,
        speedBonus:      cfg.speedBonus,
        survivalPenalty: cfg.survivalPenalty,
        reversePenalty: cfg.reversePenalty,
      },
      archCfg: {
        hidden:     hidden.length ? hidden : [64, 32, 16],
        activation: cfg.activation,
      },
      physicsCfg: {
        maxSpeed:  cfg.maxSpeed,
        friction:  cfg.friction,
        steerRate: cfg.steerRate,
      },
    };
  }

  // ── Shared drawing helpers ────────────────────────────────────────────────

  function drawTrackOn(ctx, track) {
    if (!track) return;
    const { pts, halfWidth, N } = track;

    ctx.beginPath();
    for (let i = 0; i <= N; i++) {
      const p = pts[i % N], q = pts[(i + 1) % N];
      const nx = -(q[1] - p[1]), ny = q[0] - p[0];
      const len = Math.hypot(nx, ny) || 1;
      const ox = p[0] + nx / len * halfWidth, oy = p[1] + ny / len * halfWidth;
      i === 0 ? ctx.moveTo(ox, oy) : ctx.lineTo(ox, oy);
    }
    ctx.closePath();
    ctx.moveTo(0, 0);
    for (let i = N; i >= 0; i--) {
      const p = pts[i % N], q = pts[(i + 1) % N];
      const nx = -(q[1] - p[1]), ny = q[0] - p[0];
      const len = Math.hypot(nx, ny) || 1;
      const ix = p[0] - nx / len * halfWidth, iy = p[1] - ny / len * halfWidth;
      i === N ? ctx.moveTo(ix, iy) : ctx.lineTo(ix, iy);
    }
    ctx.closePath();
    ctx.fillStyle = COL.trackFill;
    ctx.fill('evenodd');

    ctx.strokeStyle = COL.trackEdge;
    ctx.lineWidth   = 2;
    for (let side = -1; side <= 1; side += 2) {
      ctx.beginPath();
      for (let i = 0; i <= N; i++) {
        const p = pts[i % N], q = pts[(i + 1) % N];
        const nx = -(q[1] - p[1]), ny = q[0] - p[0];
        const len = Math.hypot(nx, ny) || 1;
        const ex = p[0] + side * nx / len * halfWidth;
        const ey = p[1] + side * ny / len * halfWidth;
        i === 0 ? ctx.moveTo(ex, ey) : ctx.lineTo(ex, ey);
      }
      ctx.closePath();
      ctx.stroke();
    }

    ctx.strokeStyle = '#303030';
    ctx.lineWidth   = 1;
    ctx.setLineDash([12, 12]);
    ctx.beginPath();
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p[0], p[1]) : ctx.lineTo(p[0], p[1]));
    ctx.closePath();
    ctx.stroke();
    ctx.setLineDash([]);

    const p0 = pts[0], p1 = pts[1];
    const nx = -(p1[1] - p0[1]), ny = p1[0] - p0[0];
    const len = Math.hypot(nx, ny) || 1;
    ctx.strokeStyle = '#ffffff44';
    ctx.lineWidth   = 2;
    ctx.beginPath();
    ctx.moveTo(p0[0] - nx / len * halfWidth, p0[1] - ny / len * halfWidth);
    ctx.lineTo(p0[0] + nx / len * halfWidth, p0[1] + ny / len * halfWidth);
    ctx.stroke();
  }

  function drawCarOn(ctx, car, color, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(car.x, car.y);
    ctx.rotate(car.angle + Math.PI / 2);
    ctx.fillStyle   = color;
    ctx.strokeStyle = '#000';
    ctx.lineWidth   = 0.5;
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(-5, 6);
    ctx.lineTo(5, 6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  function drawFitnessChart(svgEl, genHistory) {
    if (!svgEl || !genHistory || genHistory.length < 2) { if (svgEl) svgEl.innerHTML = ''; return; }
    const W = 260, H = 70, pad = 4;
    const vals = genHistory.map(h => h.best);
    const means = genHistory.map(h => h.mean);
    const max  = Math.max(...vals, 0.1);
    const line = (arr, color, width) => {
      const pts = arr.map((v, i) => {
        const x = pad + (i / (arr.length - 1)) * (W - 2 * pad);
        const y = H - pad - (v / max) * (H - 2 * pad);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      }).join(' ');
      return `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linejoin="round" opacity="0.8"/>`;
    };
    svgEl.innerHTML = line(means, '#555', 1) + line(vals, '#ffd600', 1.5);
  }

  // ── Config section builder ─────────────────────────────────────────────────
  // Returns the section HTML and a function to wire up event listeners.

  function buildConfigPanel(netId) {
    const cfg = getPluginCfg(netId);

    const S = (label, color = '#4a4a00', bg = '#1a1a00') =>
      `background:${bg};border:1px solid ${color};border-radius:6px;padding:10px 14px;margin-bottom:8px;`;
    const HL = (color = '#ffd600') => `font-size:12px;font-weight:700;color:${color};margin-bottom:8px;letter-spacing:.05em;`;
    const row = `display:flex;align-items:center;gap:8px;margin-bottom:5px;font-size:12px;color:#aaa;`;
    const label = `min-width:140px;`;
    const val = `min-width:36px;text-align:right;color:#e0e0e0;font-weight:600;`;

    const checkRow = (id, text, checked) =>
      `<label style="${row}cursor:pointer;">
        <input type="checkbox" id="${id}" ${checked ? 'checked' : ''}
          style="accent-color:#ffd600;width:14px;height:14px;">
        <span style="color:#bbb;">${text}</span>
      </label>`;

    const sliderRow = (id, label_, min, max, step, value, unit = '') =>
      `<div style="${row}">
        <span style="${label}">${label_}</span>
        <input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${value}"
          style="flex:1;accent-color:#ffd600;">
        <span id="${id}-v" style="${val}">${value}${unit}</span>
      </div>`;

    const html = `
      <div style="display:grid;gap:0;">

        <!-- Sensor Inputs -->
        <div style="${S()}">
          <div style="${HL()}">⬡ SENSOR INPUTS</div>
          ${sliderRow('cfg-ray-count',  'Ray count',   3,   15,  1,  cfg.rayCount,     ''   )}
          ${sliderRow('cfg-ray-spread', 'Ray spread',  30, 360,  5,  cfg.raySpreadDeg, '°'  )}
          ${sliderRow('cfg-ray-dist',   'Ray max dist', 10, 120, 5,  cfg.rayMaxDist,   'px' )}
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 16px;margin-top:4px;">
            ${checkRow('cfg-use-speed',    'Speed sensor',         cfg.useSpeed)}
            ${checkRow('cfg-use-steer',    'Steer memory',         cfg.useSteerMemory)}
            ${checkRow('cfg-use-centre',   'Distance to centre',   cfg.useDistToCenter)}
            ${checkRow('cfg-use-curve',    'Track curvature ahead',cfg.useTrackCurvature)}
          </div>
          <div id="cfg-dim-preview" style="margin-top:8px;font-size:11px;color:#666;
            background:#111;border-radius:3px;padding:5px 8px;font-family:monospace;">
          </div>
        </div>

        <!-- Fitness Formula -->
        <div style="${S('#004a00', '#001a00')}">
          <div style="${HL('#00e676')}">⬟ FITNESS FORMULA</div>
          <div style="font-size:11px;color:#555;margin-bottom:8px;">
            fitness = (progress × weight + speedBonus) × survivalFactor
          </div>
          ${sliderRow('cfg-prog-w',    'Progress weight',  0, 3,    0.05, cfg.progressWeight,  '')}
          ${sliderRow('cfg-speed-b',   'Speed bonus',      0, 0.2,  0.005, cfg.speedBonus,     '')}
          ${sliderRow('cfg-surv',      'Survival factor',  0, 1,    0.05, cfg.survivalPenalty, '')}
          ${sliderRow('cfg-reverse',   'Reverse penalty',  0, 1,    0.05, cfg.reversePenalty,  '')}
        </div>

        <!-- Architecture -->
        <div style="${S('#003a4a', '#00101a')}">
          <div style="${HL('#64b5f6')}">⬡ NEURAL ARCHITECTURE</div>
          <div style="${row}">
            <span style="${label}">Hidden layers</span>
            <input id="cfg-hidden" type="text" value="${cfg.hiddenStr}"
              style="flex:1;background:#111;border:1px solid #2a4a5a;border-radius:3px;
                color:#e0e0e0;padding:3px 7px;font-size:12px;font-family:monospace;">
          </div>
          <div style="${row}margin-top:4px;">
            <span style="${label}">Activation</span>
            <select id="cfg-activation"
              style="flex:1;background:#111;border:1px solid #2a4a5a;border-radius:3px;
                color:#e0e0e0;padding:3px 7px;font-size:12px;">
              <option value="tanh"    ${cfg.activation==='tanh'    ?'selected':''}>tanh</option>
              <option value="relu"    ${cfg.activation==='relu'    ?'selected':''}>ReLU</option>
              <option value="sigmoid" ${cfg.activation==='sigmoid' ?'selected':''}>sigmoid</option>
            </select>
          </div>
          <div id="cfg-arch-preview" style="margin-top:8px;font-size:11px;color:#666;
            background:#111;border-radius:3px;padding:5px 8px;font-family:monospace;">
          </div>
        </div>

        <!-- Physics -->
        <div style="${S('#3a003a', '#150015')}">
          <div style="${HL('#ce93d8')}">⬡ PHYSICS</div>
          ${sliderRow('cfg-maxspeed', 'Max speed',   50,  600, 10, cfg.maxSpeed,   'px/s')}
          ${sliderRow('cfg-friction', 'Friction',    0.7, 1.0, 0.01, cfg.friction, ''   )}
          ${sliderRow('cfg-steer',    'Steer rate',  0.5, 6.0, 0.1, cfg.steerRate, ''   )}
        </div>

        <div style="font-size:11px;color:#444;padding:4px 6px;">
          Changes take effect when you click <strong style="color:#666;">Start</strong>
          or <strong style="color:#666;">New evolution</strong>.
        </div>
      </div>
    `;

    function wire(root) {
      const cfg = getPluginCfg(netId);

      function updatePreview() {
        const dim = computeInputDim(cfg);
        const h   = parseHidden(cfg.hiddenStr);
        const net = [dim, ...h, 2].join(' → ');
        const inp = [
          `${cfg.rayCount} rays`,
          cfg.useSpeed          ? 'speed'     : null,
          cfg.useSteerMemory    ? 'steer mem' : null,
          cfg.useDistToCenter   ? 'dist ctr'  : null,
          cfg.useTrackCurvature ? 'curvature' : null,
        ].filter(Boolean).join(' · ');
        const dimEl  = root.querySelector('#cfg-dim-preview');
        const archEl = root.querySelector('#cfg-arch-preview');
        if (dimEl)  dimEl.textContent  = `Input dim: ${dim}  [${inp}]`;
        if (archEl) archEl.textContent = `Net: ${net}  (${dim * h[0] + h.reduce((s,v,i,a)=>i?s+a[i-1]*v:s,0) + (h[h.length-1]||dim)*2} weights approx)`;
      }

      // Slider helper
      function bindSlider(id, key, parse = parseFloat) {
        const el = root.querySelector(`#${id}`);
        const vl = root.querySelector(`#${id}-v`);
        if (!el) return;
        el.addEventListener('input', () => {
          cfg[key] = parse(el.value);
          if (vl) vl.textContent = el.value + (vl.textContent.replace(/[\d.]+/, '') || '');
          updatePreview();
        });
      }
      // Checkbox helper
      function bindCheck(id, key) {
        const el = root.querySelector(`#${id}`);
        if (!el) return;
        el.addEventListener('change', () => { cfg[key] = el.checked; updatePreview(); });
      }

      bindSlider('cfg-ray-count',  'rayCount',        parseInt);
      bindSlider('cfg-ray-spread', 'raySpreadDeg',    parseInt);
      bindSlider('cfg-ray-dist',   'rayMaxDist',      parseInt);
      bindSlider('cfg-prog-w',     'progressWeight');
      bindSlider('cfg-speed-b',    'speedBonus');
      bindSlider('cfg-surv',       'survivalPenalty');
      bindSlider('cfg-reverse',    'reversePenalty');
      bindSlider('cfg-maxspeed',   'maxSpeed',        parseInt);
      bindSlider('cfg-friction',   'friction');
      bindSlider('cfg-steer',      'steerRate');

      bindCheck('cfg-use-speed',   'useSpeed');
      bindCheck('cfg-use-steer',   'useSteerMemory');
      bindCheck('cfg-use-centre',  'useDistToCenter');
      bindCheck('cfg-use-curve',   'useTrackCurvature');

      const hiddenEl = root.querySelector('#cfg-hidden');
      if (hiddenEl) hiddenEl.addEventListener('input', () => { cfg.hiddenStr = hiddenEl.value; updatePreview(); });

      const actEl = root.querySelector('#cfg-activation');
      if (actEl) actEl.addEventListener('change', () => { cfg.activation = actEl.value; updatePreview(); });

      updatePreview();
    }

    return { html, wire };
  }

  // ── Template ──────────────────────────────────────────────────────────────
  api.registerTemplate({
    id: 'self-driving-car',
    name: 'Self-Driving Car (Neuroevolution)',
    kind: 'classifier',
    pluginKind: 'self-driving-car',
    desc: 'A population of cars evolves to lap a procedural track. Configure sensors, fitness, architecture and physics freely.',
    arch: { kind: 'classifier', pluginKind: 'self-driving-car',
            inputDim: 11, outputDim: 2, hidden: [64, 32, 16], activation: 'tanh', dropout: 0 },
    training: { optimizer: 'adam', learningRate: 0.05, batchSize: 20, epochs: 0, seed: 42, workers: 0 },
    trainingData: {},
  });

  api.registerTrainSettings('self-driving-car', {
    lr:        { label: 'Mutation std',    hint: 'Weight mutation σ — lower = finer search (default 0.05)' },
    bs:        { label: 'Population size', hint: 'Cars simulated per generation (default 20)' },
    epochs:    { label: 'Generations',     hint: 'Max generations (0 = unlimited)' },
    seed:      { label: 'Track seed',      hint: 'Seed for procedural track generation' },
    workers:   { hidden: true },
    optimizer: { hidden: true },
    sectionHint: 'Neuroevolution settings — applied at Start.',
  });

  // ── Train editor (training data section) ──────────────────────────────────
  api.registerTrainEditor('self-driving-car', function (root, network) {
    const netId       = (network && network.id) || 'car-default';
    const { html, wire } = buildConfigPanel(netId);

    root.innerHTML = `
      <div style="display:grid;gap:0;max-width:560px;">
        <div style="background:#1a1a00;border:1px solid #4a4a00;border-radius:6px;
          padding:10px 14px;margin-bottom:10px;">
          <div style="font-size:13px;font-weight:600;color:#ffd600;margin-bottom:4px;">
            Neuroevolution — configure your experiment
          </div>
          <div style="font-size:11px;color:#777;line-height:1.6;">
            Cars are neural networks evolved via selective reproduction.
            Tune <strong style="color:#aaa;">sensors</strong> to control what the car perceives,
            <strong style="color:#aaa;">fitness</strong> to define what success means,
            <strong style="color:#aaa;">architecture</strong> to shape the network, and
            <strong style="color:#aaa;">physics</strong> to change how the car drives.
          </div>
        </div>
        ${html}
      </div>
    `;
    wire(root);
  });

  // ── Train renderer ─────────────────────────────────────────────────────────
  api.registerTrainRenderer('self-driving-car', function (root, network, nb) {
    let _raf         = null;
    let _running     = false;
    let _initialized = false;
    let _cachedTrack = null;

    const instanceId = (network && network.id) || 'car-default';
    const inv = (ch, extra = {}) => nb.invoke(ch, { instanceId, ...extra });

    const t          = (network && network.training) || {};
    const cfgSeed    = (t.seed      || 42)   >>> 0;
    const cfgPopSize = (t.batchSize | 0)     || 20;
    const cfgMutStd  = t.learningRate        || 0.05;
    const cfgGens    = (t.epochs    | 0)     || 0;

    root.innerHTML = `
      <div class="panel" style="max-width:960px;">
        <h2>Self-Driving Car — Neuroevolution</h2>
        <p style="font-size:12px;color:#777;margin:-4px 0 16px;">
          Evolving ${cfgPopSize} cars · Mutation std: ${cfgMutStd}
          · ${cfgGens > 0 ? `Max ${cfgGens} generations` : 'Unlimited generations'}.
        </p>

        <div style="display:grid;grid-template-columns:${CW}px 1fr;gap:20px;align-items:start;">

          <div>
            <canvas id="car-canvas" width="${CW}" height="${CH}"
              style="display:block;border:1px solid #2a2a2a;border-radius:4px;background:#0d0d0d;"></canvas>
            <div class="row" style="margin-top:10px;gap:8px;flex-wrap:wrap;">
              <button class="btn primary" id="car-start">Start</button>
              <button class="btn"         id="car-pause">Pause</button>
              <button class="btn"         id="car-reset">New evolution</button>
              <button class="btn"         id="car-newtrack">New track</button>
            </div>
            <div style="margin-top:8px;display:flex;align-items:center;gap:8px;font-size:12px;color:#666;">
              Ticks / frame:
              <input id="car-speed" type="range" min="1" max="12" value="2" style="width:90px;">
              <span id="car-speed-val">2</span>
            </div>
          </div>

          <div style="display:grid;gap:12px;">

            <div class="kpis" style="grid-template-columns:repeat(2,1fr);">
              <div class="kpi"><div class="k">Generation</div><div class="v" id="car-gen">0</div></div>
              <div class="kpi"><div class="k">Alive</div><div class="v" id="car-alive">0 / ${cfgPopSize}</div></div>
              <div class="kpi"><div class="k">Gen best</div><div class="v" id="car-genbest">—</div></div>
              <div class="kpi"><div class="k">All-time best</div><div class="v" id="car-best">—</div></div>
            </div>

            <div class="section">
              <h3>Best fitness per generation <span id="car-mean-label" style="font-weight:400;color:#555;font-size:11px;">(yellow = best, grey = mean)</span></h3>
              <svg id="car-chart" viewBox="0 0 260 70" preserveAspectRatio="none"
                style="width:100%;height:70px;display:block;background:#0d0d0d;border-radius:4px;"></svg>
            </div>

            <div id="car-config-summary" style="font-size:11px;color:#444;line-height:1.8;
              background:#111;border:1px solid #222;border-radius:4px;padding:8px 12px;">
            </div>

          </div>
        </div>
      </div>
    `;

    const canvas = document.getElementById('car-canvas');
    const ctx    = canvas.getContext('2d');

    function drawState(s) {
      ctx.clearRect(0, 0, CW, CH);
      ctx.fillStyle = COL.bg;
      ctx.fillRect(0, 0, CW, CH);

      const track = (s && s.track) || _cachedTrack;
      if (!track) return;
      if (s && s.track) _cachedTrack = s.track;
      drawTrackOn(ctx, track);

      if (!s || !s.cars) return;
      for (const c of s.cars) {
        if (!c.alive) drawCarOn(ctx, c, COL.carDead, 0.35);
      }

      let bestIdx = -1, bestLaps = -1;
      for (let i = 0; i < s.cars.length; i++) {
        if (s.cars[i].alive && s.cars[i].laps >= bestLaps) {
          bestLaps = s.cars[i].laps; bestIdx = i;
        }
      }
      for (let i = 0; i < s.cars.length; i++) {
        const c = s.cars[i];
        if (!c.alive) continue;
        drawCarOn(ctx, c, i === bestIdx ? COL.carBest : COL.carAlive, i === bestIdx ? 1.0 : 0.75);
      }
    }

    function updateStats(s) {
      if (!s) return;
      const ps = s.popSize || cfgPopSize;
      document.getElementById('car-gen').textContent     = s.generation;
      document.getElementById('car-alive').textContent   = `${s.aliveCnt} / ${ps}`;
      document.getElementById('car-genbest').textContent = s.genBestFit > 0 ? s.genBestFit.toFixed(3) : '—';
      document.getElementById('car-best').textContent    = s.bestFit    > 0 ? s.bestFit.toFixed(3)    : '—';
      drawFitnessChart(document.getElementById('car-chart'), s.genHistory);
    }

    function updateConfigSummary() {
      const cfg = getPluginCfg(instanceId);
      const dim = computeInputDim(cfg);
      const h   = parseHidden(cfg.hiddenStr);
      const el  = document.getElementById('car-config-summary');
      if (!el) return;
      const sensors = [
        `${cfg.rayCount} rays (±${(cfg.raySpreadDeg/2).toFixed(0)}°, ${cfg.rayMaxDist}px)`,
        cfg.useSpeed          ? 'speed'     : null,
        cfg.useSteerMemory    ? 'steer mem' : null,
        cfg.useDistToCenter   ? 'dist ctr'  : null,
        cfg.useTrackCurvature ? 'curvature' : null,
      ].filter(Boolean).join(' · ');
      el.innerHTML =
        `<span style="color:#555;">Sensors:</span> <span style="color:#888;">${sensors}</span><br>` +
        `<span style="color:#555;">Net:</span>     <span style="color:#888;">${[dim, ...h, 2].join(' → ')} (${cfg.activation})</span><br>` +
        `<span style="color:#555;">Fitness:</span> <span style="color:#888;">progress×${cfg.progressWeight} + speed×${cfg.speedBonus}, survival×${cfg.survivalPenalty}, reverse×${cfg.reversePenalty}</span><br>` +
        `<span style="color:#555;">Physics:</span> <span style="color:#888;">maxSpd=${cfg.maxSpeed} · friction=${cfg.friction} · steer=${cfg.steerRate}</span>`;
    }

    function readLiveSettings() {
      const lrEl = document.getElementById('t-lr');
      const bsEl = document.getElementById('t-bs');
      const epEl = document.getElementById('t-ep');
      return {
        mutStd:  lrEl ? Math.max(0,   parseFloat(lrEl.value) || cfgMutStd)  : cfgMutStd,
        popSize: bsEl ? Math.max(4,   parseInt(bsEl.value)   || cfgPopSize) : cfgPopSize,
        maxGens: epEl ? Math.max(0,   parseInt(epEl.value)   || 0)          : cfgGens,
      };
    }

    async function tick() {
      if (!_running || !canvas.isConnected) return;
      const ticks = parseInt(document.getElementById('car-speed').value) || 2;
      const live  = readLiveSettings();
      try {
        const s = await inv('self-driving-car:step', { ticks, ...live });
        if (s) { drawState(s); updateStats(s); }
      } catch (_) {}
      _raf = requestAnimationFrame(tick);
    }

    async function startSim() {
      if (!_initialized) {
        const cfg = getPluginCfg(instanceId);
        updateConfigSummary();
        const r = await inv('self-driving-car:init', {
          seed: cfgSeed, popSize: cfgPopSize, mutStd: cfgMutStd, generations: cfgGens,
          ...cfgToPayload(cfg),
        });
        if (r && r.error) { console.error('[self-driving-car]', r.error); return; }
        _initialized = true;
      } else {
        await inv('self-driving-car:start');
      }
      if (_running) return;
      _running = true;
      _raf = requestAnimationFrame(tick);
    }

    function pauseSim() {
      _running = false;
      inv('self-driving-car:stop');
      if (_raf) { cancelAnimationFrame(_raf); _raf = null; }
    }

    async function resetSim() {
      pauseSim();
      await inv('self-driving-car:reset');
      _initialized = true;
      _cachedTrack = null;
      ctx.clearRect(0, 0, CW, CH);
      ctx.fillStyle = COL.bg;
      ctx.fillRect(0, 0, CW, CH);
      ['car-gen', 'car-alive', 'car-genbest', 'car-best'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = id === 'car-gen' ? '0' : id === 'car-alive' ? `0 / ${cfgPopSize}` : '—';
      });
      const svg = document.getElementById('car-chart');
      if (svg) svg.innerHTML = '';
    }

    async function newTrack() {
      const wasPaused = !_running;
      pauseSim();
      await inv('self-driving-car:newTrack');
      if (!_initialized) _initialized = true;
      if (!wasPaused) {
        await inv('self-driving-car:start');
        _running = true;
        _raf = requestAnimationFrame(tick);
      } else {
        const s = await inv('self-driving-car:getState');
        if (s) { drawState(s); updateStats(s); }
      }
    }

    document.getElementById('car-start').addEventListener('click', startSim);
    document.getElementById('car-pause').addEventListener('click', pauseSim);
    document.getElementById('car-reset').addEventListener('click', resetSim);
    document.getElementById('car-newtrack').addEventListener('click', newTrack);

    const slider = document.getElementById('car-speed');
    slider.addEventListener('input', () => {
      document.getElementById('car-speed-val').textContent = slider.value;
    });

    updateConfigSummary();
    inv('self-driving-car:getState').then(s => {
      if (s) { _initialized = true; drawState(s); updateStats(s); }
      else   { ctx.fillStyle = COL.bg; ctx.fillRect(0, 0, CW, CH); }
    }).catch(() => { ctx.fillStyle = COL.bg; ctx.fillRect(0, 0, CW, CH); });
  });

  // ── Inference renderer ────────────────────────────────────────────────────
  api.registerInferenceRenderer('self-driving-car', function (root, network, nb) {
    let _raf         = null;
    let _running     = false;
    let _ready       = false;
    let _cachedTrack = null;
    let _noiseStd    = 0;

    const instanceId = (network && network.id) || 'car-default';
    const inv = (ch, extra = {}) => nb.invoke(ch, { instanceId, ...extra });

    root.innerHTML = `
      <div class="panel" style="max-width:960px;">
        <h2>Self-Driving Car — Best Model</h2>
        <p style="font-size:12px;color:#777;margin:-4px 0 16px;">
          The best evolved genome drives the track. Add sensor noise to stress-test robustness.
        </p>

        <div style="display:grid;grid-template-columns:${CW}px 1fr;gap:20px;align-items:start;">

          <div>
            <canvas id="car-i-canvas" width="${CW}" height="${CH}"
              style="display:block;border:1px solid #2a2a2a;border-radius:4px;background:#0d0d0d;"></canvas>
            <div class="row" style="margin-top:10px;gap:8px;">
              <button class="btn primary" id="car-i-start">Start</button>
              <button class="btn"         id="car-i-pause">Pause</button>
              <button class="btn"         id="car-i-rerun">Re-run</button>
            </div>
          </div>

          <div style="display:grid;gap:12px;">

            <div class="kpis" style="grid-template-columns:repeat(2,1fr);">
              <div class="kpi"><div class="k">Trained gens</div><div class="v" id="car-i-gen">—</div></div>
              <div class="kpi"><div class="k">Best fitness</div><div class="v" id="car-i-fit">—</div></div>
              <div class="kpi"><div class="k">Laps (this run)</div><div class="v" id="car-i-laps">0</div></div>
              <div class="kpi"><div class="k">Speed (px/s)</div><div class="v" id="car-i-spd">0</div></div>
            </div>

            <div class="section">
              <h3>Sensor noise</h3>
              <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#aaa;">
                <span style="min-width:18px;">0</span>
                <input id="car-i-noise" type="range" min="0" max="40" value="0" style="flex:1;accent-color:#64b5f6;">
                <span style="min-width:28px;">0.40</span>
                <span id="car-i-noise-val" style="min-width:36px;text-align:right;color:#64b5f6;font-weight:600;">0.00</span>
              </div>
              <div style="font-size:11px;color:#555;margin-top:4px;">
                Gaussian noise σ added to each sensor reading. Drag right to stress-test robustness.
              </div>
            </div>

            <div id="car-i-sensor-info" style="font-size:11px;color:#444;line-height:1.8;
              background:#111;border:1px solid #222;border-radius:4px;padding:8px 12px;">
              <span style="color:#64b5f6;">▲</span> Best evolved car<br>
              Car auto-resets on crash or timeout.<br>
              Switch to the <strong style="color:#666;">Train</strong> tab to keep evolving.
            </div>

          </div>
        </div>
      </div>
    `;

    const canvas = document.getElementById('car-i-canvas');
    const ctx    = canvas.getContext('2d');

    function showPlaceholder(msg) {
      ctx.clearRect(0, 0, CW, CH);
      ctx.fillStyle = COL.bg;
      ctx.fillRect(0, 0, CW, CH);
      ctx.fillStyle    = '#444';
      ctx.font         = '13px monospace';
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(msg, CW / 2, CH / 2);
      ctx.textAlign    = 'left';
      ctx.textBaseline = 'alphabetic';
    }

    function drawInferState(s) {
      ctx.clearRect(0, 0, CW, CH);
      ctx.fillStyle = COL.bg;
      ctx.fillRect(0, 0, CW, CH);
      const track = (s && s.track) || _cachedTrack;
      if (!track) return;
      if (s && s.track) _cachedTrack = s.track;
      drawTrackOn(ctx, track);
      if (!s || !s.car) return;
      drawCarOn(ctx, s.car, COL.carInfer, 1.0);
      const barW = Math.round(CW * Math.min(1, (s.car.speed || 0) / 340));
      ctx.fillStyle = '#64b5f622';
      ctx.fillRect(0, CH - 4, barW, 4);
    }

    function updateInferStats(s) {
      if (!s || !s.car) return;
      document.getElementById('car-i-laps').textContent = s.car.laps;
      document.getElementById('car-i-spd').textContent  = Math.round(s.car.speed);
    }

    async function tick() {
      if (!_running || !canvas.isConnected) return;
      try {
        const s = await inv('self-driving-car:inferStep', { noiseStd: _noiseStd });
        if (s) { drawInferState(s); updateInferStats(s); }
      } catch (_) {}
      _raf = requestAnimationFrame(tick);
    }

    async function startInfer() {
      if (!_ready) {
        const r = await inv('self-driving-car:inferInit');
        if (!r || r.error) {
          showPlaceholder(r ? r.error : 'No trained model — run the Train tab first.');
          return;
        }
        document.getElementById('car-i-gen').textContent = r.generation || '—';
        document.getElementById('car-i-fit').textContent = r.bestFit != null ? r.bestFit.toFixed(3) : '—';
        if (r.track) _cachedTrack = r.track;
        // Show what sensors this model used
        if (r.sensorCfg) {
          const sc  = r.sensorCfg;
          const inp = [
            `${sc.rayCount} rays (${sc.raySpreadDeg}°, ${sc.rayMaxDist}px)`,
            sc.useSpeed          ? 'speed'     : null,
            sc.useSteerMemory    ? 'steer mem' : null,
            sc.useDistToCenter   ? 'dist ctr'  : null,
            sc.useTrackCurvature ? 'curvature' : null,
          ].filter(Boolean).join(' · ');
          const info = document.getElementById('car-i-sensor-info');
          if (info) info.innerHTML =
            `<span style="color:#64b5f6;">▲</span> Best evolved car (${r.inputDim || '?'} inputs)<br>` +
            `<span style="color:#555;">Sensors:</span> <span style="color:#777;">${inp}</span><br>` +
            `Car auto-resets on crash or timeout.`;
        }
        _ready = true;
      }
      if (_running) return;
      _running = true;
      _raf = requestAnimationFrame(tick);
    }

    function pauseInfer() {
      _running = false;
      if (_raf) { cancelAnimationFrame(_raf); _raf = null; }
    }

    async function rerun() {
      const wasRunning = _running;
      pauseInfer();
      _ready = false;
      document.getElementById('car-i-laps').textContent = '0';
      document.getElementById('car-i-spd').textContent  = '0';
      const r = await inv('self-driving-car:inferInit');
      if (!r || r.error) {
        showPlaceholder(r ? r.error : 'No trained model — run the Train tab first.');
        return;
      }
      document.getElementById('car-i-gen').textContent = r.generation || '—';
      document.getElementById('car-i-fit').textContent = r.bestFit != null ? r.bestFit.toFixed(3) : '—';
      if (r.track) _cachedTrack = r.track;
      _ready = true;
      if (wasRunning) { _running = true; _raf = requestAnimationFrame(tick); }
    }

    document.getElementById('car-i-start').addEventListener('click', startInfer);
    document.getElementById('car-i-pause').addEventListener('click', pauseInfer);
    document.getElementById('car-i-rerun').addEventListener('click', rerun);

    const noiseSlider = document.getElementById('car-i-noise');
    noiseSlider.addEventListener('input', () => {
      _noiseStd = parseInt(noiseSlider.value) / 100;
      document.getElementById('car-i-noise-val').textContent = _noiseStd.toFixed(2);
    });

    showPlaceholder('Press Start to view the best evolved model.');
  });

})(api);