'use strict';

const path = require('path');
const { app } = require('electron');

let Population, T, buildFromSpec;
try {
  ({ Population } = require(path.join(app.getAppPath(), 'src', 'engine', 'neuroevolution')));
  T = require(path.join(app.getAppPath(), 'src', 'engine', 'tensor'));
  ({ buildFromSpec } = require(path.join(app.getAppPath(), 'src', 'engine', 'model')));
} catch (e) {
  console.error('[self-driving-car] Failed to load engines:', e.message);
}

// ── Simulation constants ──────────────────────────────────────────────────────
const DEFAULT_POP_SIZE = 20;
const TRACK_PTS        = 8;
const MAX_FRAMES       = 30 * 18;   // ~18 s episode limit
const CANVAS_CX        = 350;
const CANVAS_CY        = 285;
const GRID_CELL        = 25;        // spatial grid cell size (px) — trade-off: smaller = faster lookup, larger = smaller map

// ── Default config objects (all overridable by init opts) ─────────────────────

const DEFAULT_SENSOR_CFG = {
  rayCount:          9,     // how many rays to cast (3–15)
  raySpreadDeg:      160,   // total angular sweep in degrees, centred on heading
  rayMaxDist:        40,    // max ray reach in pixels
  useSpeed:          true,  // append normalised speed to input vector
  useSteerMemory:    true,  // append last steer command (reduces oscillation)
  useDistToCenter:   false, // append normalised dist from track centre-line
  useTrackCurvature: false, // append look-ahead curvature signal
};

const DEFAULT_FITNESS_CFG = {
  progressWeight:  1.0,   // weight applied to lap + segment progress
  speedBonus:      0.01,  // bonus = finalSpeed / MAX_SPEED × this value
  survivalPenalty: 0.9,   // fitness is lowered by the total multiplied by this when a car dies early
  reversePenalty:  0.4,   // fitness is lowered by this when a car goes in reverse
};

const DEFAULT_PHYSICS_CFG = {
  maxSpeed:   340,
  accel:      230,
  brakeForce: 350,
  friction:   0.93,   // multiplicative drag each frame
  steerRate:  2.4,
  gripLoss:   0.4,    // speed lost proportional to steer × speed
  dt:         1 / 30,
};

const DEFAULT_ARCH_CFG = {
  hidden:     [64, 32, 16],
  activation: 'tanh',
};

// ── Dynamic I/O ───────────────────────────────────────────────────────────────

function computeInputDim(sc) {
  return (sc.rayCount || 9) +
    (sc.useSpeed          ? 1 : 0) +
    (sc.useSteerMemory    ? 1 : 0) +
    (sc.useDistToCenter   ? 1 : 0) +
    (sc.useTrackCurvature ? 1 : 0);
}

const OUTPUT_DIM = 2; // steer + throttle/brake

// ── LCG seeded random ─────────────────────────────────────────────────────────
function lcg(s)      { return (Math.imul(s | 0, 1664525) + 1013904223) >>> 0; }
function lcgFloat(s) { const v = (lcg(s) >>> 0) / 4294967296; return [v, lcg(s)]; }

// ── Track generation ──────────────────────────────────────────────────────────

function generateTrack(seed) {
  let rng = (seed || 0xDEADBEEF) >>> 0;
  function nextRand() { let f; [f, rng] = lcgFloat(rng); return f; }

  const initialN   = TRACK_PTS * 2;
  const baseRadius = 200;
  const complexity = Math.floor(nextRand() * 3) + 2;
  const phase      = nextRand() * Math.PI * 2;
  const lobeDepth  = 40 + nextRand() * 60;
  const jitter     = 0.15;

  const angles = Array.from({ length: initialN }, (_, i) => (i / initialN) * 2 * Math.PI);
  const radii  = angles.map(a => {
    let r = baseRadius + Math.sin(a * complexity + phase) * lobeDepth;
    r += (nextRand() - 0.5) * baseRadius * jitter;
    return Math.max(50, Math.min(230, r));
  });

  let pts = angles.map((a, i) => [
    CANVAS_CX + Math.cos(a) * radii[i],
    CANVAS_CY + Math.sin(a) * radii[i],
  ]);

  // Chaikin corner-cutting — 4 passes
  for (let iter = 0; iter < 4; iter++) {
    const next = [];
    for (let i = 0; i < pts.length; i++) {
      const p1 = pts[i], p2 = pts[(i + 1) % pts.length];
      next.push([p1[0] * 0.75 + p2[0] * 0.25, p1[1] * 0.75 + p2[1] * 0.25]);
      next.push([p1[0] * 0.25 + p2[0] * 0.75, p1[1] * 0.25 + p2[1] * 0.75]);
    }
    pts = next;
  }

  const segLens  = pts.map((p, i) => { const q = pts[(i + 1) % pts.length]; return Math.hypot(q[0] - p[0], q[1] - p[1]); });
  const totalLen = segLens.reduce((a, b) => a + b, 0);

  const track = { pts, segLens, totalLen, halfWidth: 22, N: pts.length };
  // Build spatial index in-place (stays server-side, never serialised)
  track._accel = buildTrackAccel(track);
  return track;
}

// ── Spatial acceleration structure ────────────────────────────────────────────
// Partitions track segments into a 2-D grid so isOnTrack and nearestSegIdx
// only inspect the handful of segments that overlap each cell instead of all N.

function gridKey(gx, gy) { return (gx + 500) * 100000 + (gy + 500); }

function buildTrackAccel(track) {
  const { pts, halfWidth, N } = track;
  const margin = halfWidth + 2;
  const cells  = new Map();

  for (let i = 0; i < N; i++) {
    const a = pts[i], b = pts[(i + 1) % N];
    const gx0 = Math.floor((Math.min(a[0], b[0]) - margin) / GRID_CELL);
    const gx1 = Math.floor((Math.max(a[0], b[0]) + margin) / GRID_CELL);
    const gy0 = Math.floor((Math.min(a[1], b[1]) - margin) / GRID_CELL);
    const gy1 = Math.floor((Math.max(a[1], b[1]) + margin) / GRID_CELL);
    for (let gx = gx0; gx <= gx1; gx++) {
      for (let gy = gy0; gy <= gy1; gy++) {
        const k = gridKey(gx, gy);
        if (!cells.has(k)) cells.set(k, []);
        cells.get(k).push(i);
      }
    }
  }
  return { cells, pts, halfWidth, N };
}

// ── Track geometry helpers ────────────────────────────────────────────────────

function distToSeg(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  if (lenSq < 1e-8) return Math.hypot(px - ax, py - ay);
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / lenSq));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

function isOnTrack(x, y, track) {
  const ac = track._accel;
  if (ac) {
    // Fast path: only check segments in the current grid cell
    const segs = ac.cells.get(gridKey(Math.floor(x / GRID_CELL), Math.floor(y / GRID_CELL)));
    if (!segs) return false;
    for (const i of segs) {
      const a = ac.pts[i], b = ac.pts[(i + 1) % ac.N];
      if (distToSeg(x, y, a[0], a[1], b[0], b[1]) <= ac.halfWidth) return true;
    }
    return false;
  }
  // Fallback: linear scan
  const { pts, halfWidth, N } = track;
  for (let i = 0; i < N; i++) {
    const a = pts[i], b = pts[(i + 1) % N];
    if (distToSeg(x, y, a[0], a[1], b[0], b[1]) <= halfWidth) return true;
  }
  return false;
}

function nearestSegIdx(x, y, track) {
  const ac = track._accel;
  if (ac) {
    // Check a 5×5 neighbourhood of cells — fast for typical use
    const gx = Math.floor(x / GRID_CELL), gy = Math.floor(y / GRID_CELL);
    let best = 0, bestD = Infinity;
    for (let dx = -2; dx <= 2; dx++) {
      for (let dy = -2; dy <= 2; dy++) {
        const segs = ac.cells.get(gridKey(gx + dx, gy + dy));
        if (!segs) continue;
        for (const i of segs) {
          const d = Math.hypot(x - ac.pts[i][0], y - ac.pts[i][1]);
          if (d < bestD) { bestD = d; best = i; }
        }
      }
    }
    return best;
  }
  // Fallback
  let best = 0, bestD = Infinity;
  for (let i = 0; i < track.N; i++) {
    const d = Math.hypot(x - track.pts[i][0], y - track.pts[i][1]);
    if (d < bestD) { bestD = d; best = i; }
  }
  return best;
}

function castRay(cx, cy, angle, track, maxDist, step) {
  const dx = Math.cos(angle), dy = Math.sin(angle);
  for (let d = step; d <= maxDist; d += step) {
    if (!isOnTrack(cx + dx * d, cy + dy * d, track)) return (d - step) / maxDist;
  }
  return 1.0;
}

function distToTrackCentre(car, track) {
  const { pts, N, halfWidth } = track;
  const a = pts[car.segIdx], b = pts[(car.segIdx + 1) % N];
  return Math.min(1, distToSeg(car.x, car.y, a[0], a[1], b[0], b[1]) / halfWidth);
}

function trackCurvatureAhead(car, track, lookahead = 8) {
  const { pts, N } = track;
  let seg = car.segIdx, total = 0;
  for (let i = 0; i < lookahead; i++) {
    const a = pts[seg % N], b = pts[(seg + 1) % N], c = pts[(seg + 2) % N];
    const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    const dot   = (b[0] - a[0]) * (c[0] - b[0]) + (b[1] - a[1]) * (c[1] - b[1]);
    total += Math.atan2(cross, dot);
    seg++;
  }
  return Math.max(-1, Math.min(1, total / lookahead));
}

// ── Car helpers ───────────────────────────────────────────────────────────────

function spawnCar(track) {
  const p0 = track.pts[0], p1 = track.pts[1];
  return {
    x: p0[0], y: p0[1],
    angle: Math.atan2(p1[1] - p0[1], p1[0] - p0[0]),
    speed: 10,
    alive: true,
    segIdx: 0,
    laps: 0,
    segProgress: 0,
    frames: 0,
    totalDist: 0,
    steerMemory: 0,
  };
}

function senseCar(car, track, sc, phys) {
  const sensors     = [];
  const raySpread   = (sc.raySpreadDeg || 160) * (Math.PI / 180);
  const rayCount    = sc.rayCount   || 9;
  const maxDist     = sc.rayMaxDist || 40;
  const step        = Math.max(2, maxDist / 10);
  const maxSpeed    = (phys && phys.maxSpeed) || 340;

  for (let r = 0; r < rayCount; r++) {
    const da = rayCount > 1 ? -raySpread / 2 + r * (raySpread / (rayCount - 1)) : 0;
    sensors.push(castRay(car.x, car.y, car.angle + da, track, maxDist, step));
  }
  if (sc.useSpeed)          sensors.push(car.speed / maxSpeed);
  if (sc.useSteerMemory)    sensors.push(car.steerMemory);
  if (sc.useDistToCenter)   sensors.push(distToTrackCentre(car, track));
  if (sc.useTrackCurvature) sensors.push(trackCurvatureAhead(car, track));

  return new Float32Array(sensors);
}

function stepCar(car, steerOut, throttleOut, phys) {
  const gripPenalty = phys.gripLoss * Math.abs(steerOut) * (car.speed / phys.maxSpeed);
  car.angle  += steerOut * phys.steerRate * phys.dt;
  const acc   = throttleOut > 0 ?  throttleOut * phys.accel      * phys.dt : 0;
  const brake = throttleOut < 0 ? -throttleOut * phys.brakeForce * phys.dt : 0;
  car.speed   = Math.max(0, Math.min(phys.maxSpeed,
    (car.speed + acc - brake) * phys.friction * (1 - gripPenalty)));
  car.x += Math.cos(car.angle) * car.speed * phys.dt;
  car.y += Math.sin(car.angle) * car.speed * phys.dt;
  car.steerMemory = steerOut;
  car.frames++;
}

function updateCarProgress(car, track) {
  const N      = track.N;
  const newSeg = nearestSegIdx(car.x, car.y, track);
  let delta    = newSeg - car.segIdx;
  if (delta >  N / 2) delta -= N;
  if (delta < -N / 2) delta += N;
  if (delta > 0) {
    car.segProgress += delta;
    if (car.segProgress >= N) { car.laps++; car.segProgress -= N; }
    car.totalDist += delta;
  }
  car.segIdx = newSeg;
}

function carFitness(car, track, fc) {
  const progress   = (car.laps + car.totalDist / track.N) * (fc.progressWeight || 1);
  const speedBonus = (car.speed / 340) * (fc.speedBonus || 0.01);
  const factor     = car.alive ? 1 : (fc.survivalPenalty || 0.9);
  return (progress + speedBonus) * factor - (Math.abs(car.speed) > 0.5 && car.speed < 0 ? (fc.reversePenalty || 0.4) : 0);
}

// ── Neural net forward pass ───────────────────────────────────────────────────

function netForward(model, inputArr, inputDim) {
  const x   = new T.Tensor([1, inputDim], inputArr, false);
  const out = model.forward(x, { training: false });
  return out.data;
}

// ── Gaussian noise ────────────────────────────────────────────────────────────

function gaussRand() {
  return Math.sqrt(-2 * Math.log(Math.random() + 1e-9)) * Math.cos(2 * Math.PI * Math.random());
}

// ── Sessions ──────────────────────────────────────────────────────────────────

function makeSession() {
  return {
    pop: null, popSize: DEFAULT_POP_SIZE, maxGens: 0,
    track: null, cars: [], carFit: [],
    generation: 0, bestFit: 0, genBestFit: 0,
    running: false, genHistory: [],
    inferCar: null, inferTrack: null,
    sensorCfg:  { ...DEFAULT_SENSOR_CFG },
    fitnessCfg: { ...DEFAULT_FITNESS_CFG },
    physicsCfg: { ...DEFAULT_PHYSICS_CFG },
    archCfg:    { ...DEFAULT_ARCH_CFG },
    inputDim:   computeInputDim(DEFAULT_SENSOR_CFG),
    trackDirty: false,
  };
}

const _sessions = new Map();
function getSession(id) {
  const key = id || 'default';
  if (!_sessions.has(key)) _sessions.set(key, makeSession());
  return _sessions.get(key);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function mergeCfg(defaults, overrides) {
  return overrides ? { ...defaults, ...overrides } : { ...defaults };
}

function buildArch(s) {
  return {
    kind: 'classifier',
    inputDim: s.inputDim, outputDim: OUTPUT_DIM,
    hidden: s.archCfg.hidden || [64, 32, 16],
    activation: s.archCfg.activation || 'tanh',
    dropout: 0,
  };
}

// Strip internal _accel (Map, not IPC-serialisable) before sending to renderer
function serializeTrack(track) {
  return { pts: track.pts, halfWidth: track.halfWidth, N: track.N,
           segLens: track.segLens, totalLen: track.totalLen };
}

function buildVisualState(s) {
  if (!s.cars || !s.track) return null;
  const state = {
    cars: s.cars.map(c => ({
      x: c.x, y: c.y, angle: c.angle,
      alive: c.alive, speed: c.speed, laps: c.laps,
    })),
    generation: s.generation,
    aliveCnt:   s.cars.filter(c => c.alive).length,
    popSize:    s.popSize,
    bestFit:    +s.bestFit.toFixed(3),
    genBestFit: +s.genBestFit.toFixed(3),
    genHistory: s.genHistory.slice(-60),
    hasBestGenome: s.pop !== null && s.pop.bestIndividual !== null,
    inputDim:   s.inputDim,
  };
  // Only send track when it changes — saves significant IPC payload each frame
  if (s.trackDirty) {
    state.track  = serializeTrack(s.track);
    s.trackDirty = false;
  }
  return state;
}

function resizePop(s, newSize) {
  s.popSize        = newSize;
  s.pop.size       = newSize;
  s.pop.eliteCount = Math.max(1, Math.floor(newSize * 0.2));
  s.pop.fitnesses  = new Float32Array(newSize);
  while (s.pop.individuals.length > newSize) s.pop.individuals.pop();
  if (buildFromSpec) {
    while (s.pop.individuals.length < newSize) {
      const rng = T.rngFromSeed((Math.random() * 0xFFFFFF) | 0);
      s.pop.individuals.push(buildFromSpec(s.pop.arch, rng));
    }
  }
}

// ── Core step ─────────────────────────────────────────────────────────────────

function stepGeneration(s, opts) {
  if (!s.pop || !s.track || !s.running) return null;
  const ticks = Math.max(1, Math.min((opts.ticks || 2) | 0, 12));
  const live  = (typeof opts === 'object') ? opts : {};

  // Apply live-tweakable params without restart
  if (live.mutStd  != null) s.pop.mutationStd = Math.max(0, live.mutStd);
  if (live.maxGens != null) s.maxGens = Math.max(0, live.maxGens | 0);

  for (let t = 0; t < ticks; t++) {
    let allDead = true;

    for (let i = 0; i < s.popSize; i++) {
      const car = s.cars[i];
      if (!car.alive) continue;
      allDead = false;

      const inputs   = senseCar(car, s.track, s.sensorCfg, s.physicsCfg);
      const outs     = netForward(s.pop.individuals[i], inputs, s.inputDim);
      const steer    = Math.max(-1, Math.min(1, outs[0]));
      const throttle = Math.max(-1, Math.min(1, outs[1]));

      stepCar(car, steer, throttle, s.physicsCfg);
      updateCarProgress(car, s.track);

      if (!isOnTrack(car.x, car.y, s.track) || car.frames >= MAX_FRAMES) {
        car.alive   = false;
        s.carFit[i] = carFitness(car, s.track, s.fitnessCfg);
      }
    }

    if (allDead) {
      s.pop.evaluate((_, idx) => s.carFit[idx]);
      const stats = s.pop.evolve();
      s.generation++;
      s.genHistory.push({ gen: s.generation, best: +s.pop.bestFitness.toFixed(3), mean: +stats.mean.toFixed(3) });
      if (s.genHistory.length > 100) s.genHistory.shift();
      if (s.pop.bestFitness > s.bestFit) s.bestFit = s.pop.bestFitness;
      s.genBestFit = stats.max;
      if (s.maxGens > 0 && s.generation >= s.maxGens) s.running = false;

      const newSize = live.popSize ? Math.max(4, Math.min(200, live.popSize | 0)) : s.popSize;
      if (newSize !== s.popSize) resizePop(s, newSize);

      s.cars   = Array.from({ length: s.popSize }, () => spawnCar(s.track));
      s.carFit = new Array(s.popSize).fill(0);
      break;
    }
  }

  return buildVisualState(s);
}

// ── IPC handlers ──────────────────────────────────────────────────────────────
module.exports = {
  mainHandlers: {

    'self-driving-car:init': (_, opts = {}) => {
      if (!Population || !T) return { error: 'Neuroevolution engine unavailable.' };
      const id = opts.instanceId || 'default';
      const s  = getSession(id);

      s.sensorCfg  = mergeCfg(DEFAULT_SENSOR_CFG,  opts.sensorCfg);
      s.fitnessCfg = mergeCfg(DEFAULT_FITNESS_CFG, opts.fitnessCfg);
      s.physicsCfg = mergeCfg(DEFAULT_PHYSICS_CFG, opts.physicsCfg);
      s.archCfg    = mergeCfg(DEFAULT_ARCH_CFG,    opts.archCfg);
      s.inputDim   = computeInputDim(s.sensorCfg);

      s.popSize = Math.max(4, Math.min(200, (opts.popSize | 0) || DEFAULT_POP_SIZE));
      s.maxGens = Math.max(0, (opts.generations | 0) || 0);
      const seed   = (opts.seed || 0) >>> 0;
      const mutStd = Math.max(0.001, opts.mutStd || 0.05);

      s.track      = generateTrack(seed || 0xC0FFEE);
      s.trackDirty = true;

      s.pop = new Population({
        architecture: buildArch(s),
        size:         s.popSize,
        eliteCount:   Math.max(1, Math.floor(s.popSize * 0.2)),
        pMutate:      opts.pMutate || 0.15,
        mutationStd:  mutStd,
        tournamentK:  opts.tournamentK || 3,
        seed:         opts.seed || 42,
      });

      s.cars       = Array.from({ length: s.popSize }, () => spawnCar(s.track));
      s.carFit     = new Array(s.popSize).fill(0);
      s.generation = 0;
      s.bestFit    = 0;
      s.genBestFit = 0;
      s.running    = true;
      s.genHistory = [];

      return { ok: true, track: serializeTrack(s.track), inputDim: s.inputDim };
    },

    'self-driving-car:getState': (_, opts = {}) => {
      const id = (typeof opts === 'string' ? opts : opts.instanceId) || 'default';
      const s  = getSession(id);
      s.trackDirty = true; // force track inclusion on explicit get
      return buildVisualState(s);
    },

    'self-driving-car:step': (_, opts = {}) => {
      const id = (typeof opts === 'object' ? opts.instanceId : null) || 'default';
      return stepGeneration(getSession(id), opts);
    },

    'self-driving-car:start': (_, opts = {}) => {
      const id = (typeof opts === 'string' ? opts : opts.instanceId) || 'default';
      getSession(id).running = true;
      return { ok: true };
    },

    'self-driving-car:stop': (_, opts = {}) => {
      const id = (typeof opts === 'string' ? opts : opts.instanceId) || 'default';
      getSession(id).running = false;
      return { ok: true };
    },

    'self-driving-car:newTrack': (_, opts = {}) => {
      const id   = (typeof opts === 'object' ? opts.instanceId : null) || 'default';
      const seed = (typeof opts === 'object' ? opts.seed : opts) || null;
      const s    = getSession(id);
      if (!s.pop) return { error: 'Not initialized.' };
      s.track      = generateTrack((seed || Math.floor(Math.random() * 0xFFFFFF)) >>> 0);
      s.trackDirty = true;
      s.cars       = Array.from({ length: s.popSize }, () => spawnCar(s.track));
      s.carFit     = new Array(s.popSize).fill(0);
      return { ok: true, track: serializeTrack(s.track) };
    },

    'self-driving-car:reset': (_, opts = {}) => {
      const id = (typeof opts === 'string' ? opts : opts.instanceId) || 'default';
      const s  = getSession(id);
      if (!Population || !T) return { error: 'Not initialized.' };
      const seed       = Math.floor(Math.random() * 0xFFFFFF);
      s.track          = generateTrack(seed);
      s.trackDirty     = true;
      s.pop = new Population({
        architecture: buildArch(s),
        size:         s.popSize,
        eliteCount:   Math.max(1, Math.floor(s.popSize * 0.2)),
        pMutate:      0.15, mutationStd: 0.05,
        tournamentK:  3, seed,
      });
      s.cars       = Array.from({ length: s.popSize }, () => spawnCar(s.track));
      s.carFit     = new Array(s.popSize).fill(0);
      s.generation = 0;
      s.bestFit    = 0;
      s.genBestFit = 0;
      s.running    = true;
      s.genHistory = [];
      return { ok: true };
    },

    // Release session memory when plugin is closed
    'self-driving-car:destroy': (_, opts = {}) => {
      const id = (typeof opts === 'string' ? opts : opts.instanceId) || 'default';
      _sessions.delete(id);
      return { ok: true };
    },

    // ── Inference ───────────────────────────────────────────────────────────

    'self-driving-car:inferInit': (_, opts = {}) => {
      const id = (typeof opts === 'string' ? opts : opts.instanceId) || 'default';
      const s  = getSession(id);
      if (!s.pop || !s.track) return { error: 'No trained model — run training first.' };
      const genome = s.pop.bestIndividual || s.pop.individuals[0];
      if (!genome) return { error: 'Population not ready.' };
      s.inferCar   = spawnCar(s.track);
      s.inferTrack = s.track;
      return {
        ok: true,
        track:      serializeTrack(s.inferTrack),
        generation: s.generation,
        bestFit:    +s.bestFit.toFixed(3),
        inputDim:   s.inputDim,
        sensorCfg:  s.sensorCfg,
      };
    },

    'self-driving-car:inferStep': (_, opts = {}) => {
      const id       = (typeof opts === 'object' ? opts.instanceId : null) || 'default';
      const noiseStd = (typeof opts === 'object' ? opts.noiseStd   : opts) || 0;
      const s        = getSession(id);
      if (!s.inferCar || !s.inferTrack || !s.pop) return null;
      const genome = s.pop.bestIndividual || s.pop.individuals[0];
      if (!genome) return null;

      let inputs = senseCar(s.inferCar, s.inferTrack, s.sensorCfg, s.physicsCfg);
      if (noiseStd > 0) {
        const noisy = new Float32Array(inputs.length);
        for (let i = 0; i < inputs.length; i++) noisy[i] = inputs[i] + gaussRand() * noiseStd;
        inputs = noisy;
      }

      const outs     = netForward(genome, inputs, s.inputDim);
      const steer    = Math.max(-1, Math.min(1, outs[0]));
      const throttle = Math.max(-1, Math.min(1, outs[1]));
      stepCar(s.inferCar, steer, throttle, s.physicsCfg);
      updateCarProgress(s.inferCar, s.inferTrack);

      const dead = !isOnTrack(s.inferCar.x, s.inferCar.y, s.inferTrack) || s.inferCar.frames >= MAX_FRAMES;
      if (dead) s.inferCar = spawnCar(s.inferTrack);

      return {
        track: s.trackDirty ? serializeTrack(s.inferTrack) : undefined,
        car: {
          x: s.inferCar.x, y: s.inferCar.y,
          angle: s.inferCar.angle, speed: s.inferCar.speed, laps: s.inferCar.laps,
        },
        justReset: dead,
      };
    },
  },
};